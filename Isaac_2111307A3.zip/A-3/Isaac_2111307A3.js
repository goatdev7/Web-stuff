//Function for finding arrays and displaying them
function inputs() {
  var head = document.getElementById("head");
  head.innerHTML = "Input Paragraph Entered: \n"
  var ins = document.getElementById("t1").value;
  var msg = document.getElementById("out1");
  var msg2 = document.getElementById("out2");
  var msg3 = document.getElementById("out3");
  var msg4 = document.getElementById("out4");
  msg.innerHTML = "Output:\n";
  // splitting the data
  const spl = ins.split(" ")
  //variables for later use
  const comp = [];
  const comp2 = [];
  const array = [];
  //loops to check input and store binary digits
  for (var i in spl) {
    //searching arrays
    if (spl[i][0] == '[') {
      msg2.innerHTML = "Arrays occurring in above paragraph are:\n";
      array.push(spl[i]);
    }
  }
  //running loop for removing end commas
  for (var j in array) {
    //pushing the strings in another loop for later use 
    comp.push(array[j].split("]"));
  }
  //again a loop for adding a bracket at end 
  for (var k in comp) {
    comp2.push(comp[k][0].concat(']'));

  }
  //displaying the results
  msg3.innerHTML = comp2.join("<br>");
}